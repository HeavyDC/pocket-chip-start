# Bluetooth Module Documentation

 The Bluetooth module is currently incomplete and non-functional, and should not be used. Once it has been implemented, it will connect with Bluez over D-Bus to view and control connected bluetooth devices.

#### [Bluetooth\::BluezAdapter](../../Source/System/Bluetooth/Bluetooth_BluezAdapter.h)
BluezAdapter is an extremely early prototype [GLib\::DBusProxy](../../Source/Framework/GLib/DBus/GLib_DBus_Proxy.h) class for accessing the Bluetooth adapter over D-Bus.
