# Flash Page
The flash page reboots PocketCHIP systems into fel mode so that new system software can be flashed.

![Flash Page](../images/screenshots/pages/fel.png?raw=true "Flash page guide")
1. Immediately reboots the system into fel mode. This will only work on PocketCHIP systems.
2. Closes the page, returning to the [power page](./power.md).
