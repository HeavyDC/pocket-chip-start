# Creating D-Bus Proxy Classes(WIP)
Include a brief overview here of D-Bus proxies and the GLib::DBus module.

1. Creating a DBus proxy class for a remote D-Bus object.
2. Accessing DBus object properties with GVariants
3. Calling DBus object methods, and handling method parameters and return values.
4. Handling signals from DBus objects.

