# Adding Shared Application Resources (WIP)
Brief description of the SharedResource module her.

1. Consider if it's appropriate to implement a feature using the SharedResource module.
2. Decide what kind of resource class to create.

### Using SharedResource::Resource

### Using SharedResource::Modular::Resource

### Using SharedResource::Thread::Resource

### Using SharedResource::Handler for Resource Access

### Using SharedResource::Handler as a Resource Listener
