# Using Test Classes (WIP)
When and where to create test classes.

1. Test class paths and naming conventions.
2. Using the Test template file.
3. Where to add test support classes.
4. Running application tests.

